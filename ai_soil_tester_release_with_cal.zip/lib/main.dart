import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: (_) => AppState(),
    child: const MyApp(),
  ));
}

class AppState extends ChangeNotifier {
  BluetoothConnection? connection;
  bool isConnected = false;
  String deviceName = '';
  String lastRaw = '';
  Map<String, double> latest = {};
  String resultText = '';
  bool pumpOn = false;
  List<String> logs = [];

  // calibration values
  double phSlope = 1.0; // multiplicative correction (applied as corrected = raw * phSlope + phOffset)
  double phOffset = 0.0;
  double moistDryObserved = 0.0;
  double moistWetObserved = 100.0;

  AppState() {
    _loadCalibration();
  }

  void addLog(String s) {
    final t = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
    logs.insert(0, '$t  $s');
    notifyListeners();
  }

  Future<void> _loadCalibration() async {
    final p = await SharedPreferences.getInstance();
    phSlope = p.getDouble('phSlope') ?? 1.0;
    phOffset = p.getDouble('phOffset') ?? 0.0;
    moistDryObserved = p.getDouble('moistDryObserved') ?? 0.0;
    moistWetObserved = p.getDouble('moistWetObserved') ?? 100.0;
    addLog('Calibration loaded');
    notifyListeners();
  }

  Future<void> savePhCalibration(double slope, double offset) async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('phSlope', slope);
    await p.setDouble('phOffset', offset);
    phSlope = slope;
    phOffset = offset;
    addLog('Saved pH calibration: slope=$slope offset=$offset');
    notifyListeners();
  }

  Future<void> saveMoistCalibration(double dryObs, double wetObs) async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('moistDryObserved', dryObs);
    await p.setDouble('moistWetObserved', wetObs);
    moistDryObserved = dryObs;
    moistWetObserved = wetObs;
    addLog('Saved moisture calibration: dry=$dryObs wet=$wetObs');
    notifyListeners();
  }

  void setConnected(BluetoothConnection conn, String name) {
    connection = conn;
    isConnected = true;
    deviceName = name;
    addLog('Connected to $name');
    notifyListeners();
  }

  void setDisconnected() {
    connection = null;
    isConnected = false;
    deviceName = '';
    addLog('Disconnected');
    notifyListeners();
  }

  void updateRaw(String r) {
    lastRaw = r;
    addLog('RX: $r');
    notifyListeners();
  }

  void updateLatest(Map<String, double> map) {
    latest = map;
    notifyListeners();
  }

  void updateResult(String r) {
    resultText = r;
    addLog('Result: $r');
    notifyListeners();
  }

  Future<void> togglePump() async {
    if (connection == null) return;
    final cmd = pumpOn ? 'PUMP_OFF\n' : 'PUMP_ON\n';
    try {
      connection!.output.add(utf8.encode(cmd));
      await connection!.output.allSent;
      pumpOn = !pumpOn;
      addLog('Sent: $cmd');
      notifyListeners();
    } catch (e) {
      addLog('Pump send error: $e');
    }
  }

  // apply calibration: input raw pH value -> corrected pH
  double applyPhCalibration(double raw) {
    return raw * phSlope + phOffset;
  }

  // map observed moisture to 0-100 using stored observed dry/wet
  double applyMoistCalibration(double observed) {
    if (moistWetObserved == moistDryObserved) return observed;
    double pct = ((observed - moistDryObserved) / (moistWetObserved - moistDryObserved)) * 100.0;
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    return pct;
  }
}

class SoilAI {
  static String analyze(Map<String, double> s) {
    final pH = s['pH'] ?? double.nan;
    final n = s['N'] ?? double.nan;
    final p = s['P'] ?? double.nan;
    final k = s['K'] ?? double.nan;
    final moist = s['moist'] ?? double.nan;

    final Map<String, double> scores = {
      'Rice': 0,
      'Wheat': 0,
      'Tomato': 0,
      'Maize': 0,
      'Potato': 0,
    };

    void phScore(String crop, double low, double high, double w) {
      if (pH.isNaN) return;
      final dist = (pH < low) ? (low - pH) : (pH > high) ? (pH - high) : 0;
      scores[crop] = (scores[crop] ?? 0) + (w - dist);
    }

    phScore('Rice', 5.0, 6.5, 3.0);
    phScore('Wheat', 6.0, 7.5, 3.0);
    phScore('Tomato', 5.5, 7.0, 3.0);
    phScore('Maize', 5.5, 7.0, 3.0);
    phScore('Potato', 4.8, 6.0, 3.0);

    void npkScore(String crop, double nI, double pI, double kI) {
      if (!n.isNaN) scores[crop] = (scores[crop] ?? 0) + (1.0 - ((n - nI).abs() / (nI + 20)).clamp(0.0,1.0));
      if (!p.isNaN) scores[crop] = (scores[crop] ?? 0) + (1.0 - ((p - pI).abs() / (pI + 10)).clamp(0.0,1.0));
      if (!k.isNaN) scores[crop] = (scores[crop] ?? 0) + (1.0 - ((k - kI).abs() / (kI + 20)).clamp(0.0,1.0));
    }

    npkScore('Rice', 30,20,20);
    npkScore('Wheat', 25,15,15);
    npkScore('Tomato', 40,25,30);
    npkScore('Maize', 35,18,25);
    npkScore('Potato', 20,15,30);

    if (!moist.isNaN) {
      if (moist < 30) scores.updateAll((k,v) => v - 1.0);
      else if (moist > 70) scores.updateAll((k,v) => v - 0.5);
      else scores.updateAll((k,v) => v + 0.5);
    }

    final sorted = scores.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
    final top = sorted.take(3).map((e)=>'${e.key} (${e.value.toStringAsFixed(2)})').join(', ');

    final List<String> notes = [];
    if (!n.isNaN) {
      if (n < 20) notes.add('Nitrogen low — add urea/compost');
      else if (n > 60) notes.add('Nitrogen high — avoid more N');
    }
    if (!p.isNaN) {
      if (p < 15) notes.add('Phosphorus low — add bone meal/rock phosphate');
    }
    if (!k.isNaN) {
      if (k < 20) notes.add('Potassium low — add potash/wood ash');
    }
    if (!pH.isNaN) {
      if (pH < 5.5) notes.add('Soil acidic — add lime to raise pH');
      else if (pH > 7.8) notes.add('Soil alkaline — add sulfur or organic matter');
    }

    final res = 'Top crops: $top\nNotes: ${notes.join('; ')}';
    return res;
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Soil Tester',
      theme: ThemeData(primarySwatch: Colors.green),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds:2), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomePage()));
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[700],
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Image.asset('assets/logo.png', width:120, height:120),
          const SizedBox(height:12),
          const Text('AI Soil Tester', style: TextStyle(fontSize:22, color:Colors.white)),
          const SizedBox(height:6),
          const Text('Bluetooth Soil Device Interface', style: TextStyle(color:Colors.white70)),
        ]),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  BluetoothState _bluetoothState = BluetoothState.UNKNOWN;
  List<BluetoothDevice> _pairedDevices = [];
  BluetoothConnection? _connection;
  StreamSubscription<Uint8List>? _readSub;

  @override
  void initState() {
    super.initState();
    FlutterBluetoothSerial.instance.state.then((s) {
      setState(() => _bluetoothState = s);
    });
    _getPaired();
  }

  Future<void> _getPaired() async {
    final devices = await FlutterBluetoothSerial.instance.getBondedDevices();
    setState(() => _pairedDevices = devices);
  }

  Future<void> _connectToDevice(BluetoothDevice device) async {
    final appState = Provider.of<AppState>(context, listen: false);
    try {
      appState.addLog('Connecting to ${device.name}');
      final conn = await BluetoothConnection.toAddress(device.address);
      appState.setConnected(conn, device.name ?? device.address);
      _connection = conn;
      _readSub = conn.input?.listen((data) {
        final s = utf8.decode(data);
        _handleReceived(s);
      }, onDone: () {
        appState.setDisconnected();
        appState.addLog('Connection closed');
      });
    } catch (e) {
      Provider.of<AppState>(context, listen: false).addLog('Connection error: $e');
    }
  }

  void _handleReceived(String raw) {
    final appState = Provider.of<AppState>(context, listen: false);
    final lines = raw.split('\n');
    for (var line in lines) {
      line = line.trim();
      if (line.isEmpty) continue;
      appState.updateRaw(line);
      final parsed = _parseSensorLine(line);
      if (parsed.isNotEmpty) {
        // apply calibration if available
        if (parsed.containsKey('pH')) {
          final rawph = parsed['pH']!;
          final corrected = Provider.of<AppState>(context, listen: false).applyPhCalibration(rawph);
          parsed['pH'] = double.parse(corrected.toStringAsFixed(2));
        }
        if (parsed.containsKey('moist')) {
          final rawm = parsed['moist']!;
          final corr = Provider.of<AppState>(context, listen: false).applyMoistCalibration(rawm);
          parsed['moist'] = double.parse(corr.toStringAsFixed(1));
        }
        appState.updateLatest(parsed);
        final analysis = SoilAI.analyze(parsed);
        appState.updateResult(analysis);
      } else {
        appState.addLog('Parse failed for: $line');
      }
    }
  }

  Map<String,double> _parseSensorLine(String line) {
    final Map<String,double> out = {};
    final parts = line.split(RegExp(r'[,;\s]+'));
    for (var p in parts) {
      final kv = p.split(':');
      if (kv.length != 2) continue;
      final k = kv[0].toLowerCase();
      final v = double.tryParse(kv[1].replaceAll(RegExp(r'[^0-9.\-]'), ''));
      if (v == null) continue;
      if (k == 'ph') out['pH'] = v;
      else if (k == 'n') out['N'] = v;
      else if (k == 'p') out['P'] = v;
      else if (k == 'k') out['K'] = v;
      else if (k == 'moist' || k == 'moisture') out['moist'] = v;
      else if (k == 'ec') out['ec'] = v;
    }
    return out;
  }

  @override
  void dispose() {
    _readSub?.cancel();
    _connection?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('AI Soil Tester'), actions: [
        IconButton(icon: const Icon(Icons.history), onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HistoryPage()));
        }),
        IconButton(icon: const Icon(Icons.settings), onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CalibrationPage()));
        })
      ]),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Bluetooth state: $_bluetoothState'),
          const SizedBox(height: 8),
          const Text('Paired devices:', style: TextStyle(fontWeight: FontWeight.bold)),
          if (_pairedDevices.isEmpty) const Padding(padding: EdgeInsets.all(8.0), child: Text('No paired devices. Pair HC-05/06 in Android Settings.')),
          ..._pairedDevices.map((d) => ListTile(
            title: Text(d.name ?? d.address ?? 'Unknown'),
            subtitle: Text(d.address ?? ''),
            trailing: ElevatedButton(onPressed: () => _connectToDevice(d), child: const Text('Connect')),
          )),
          const Divider(),
          const Text('Connected device:', style: TextStyle(fontWeight: FontWeight.bold)),
          Text(appState.deviceName),
          const SizedBox(height: 10),
          Card(child: Padding(padding: const EdgeInsets.all(12.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Latest sensor values:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Raw: ' ),
            const SizedBox(height: 6),
          ]))),
          const SizedBox(height: 8),
          if (appState.latest.isNotEmpty) ...[
            Wrap(spacing:10, runSpacing:6, children: appState.latest.entries.map((e)=>Chip(label: Text('${e.key}: ${e.value}'))).toList()),
            const SizedBox(height:8),
            const Text('AI Analysis:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(appState.resultText),
            const SizedBox(height:10),
            Row(children: [
              ElevatedButton(onPressed: appState.isConnected?() => appState.togglePump():null, child: Text(appState.pumpOn?'Stop Pump':'Start Pump')),
              const SizedBox(width:12),
              ElevatedButton(onPressed: () {
                final example = 'pH:6.5,N:30,P:18,K:12,moist:45';
                final parsed = _parseSensorLine(example);
                appState.updateLatest(parsed);
                appState.updateResult(SoilAI.analyze(parsed));
              }, child: const Text('Run Demo'))
            ])
          ],
          const Divider(),
          const Text('Logs:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height:200, child: ListView(children: appState.logs.map((l)=>Text(l)).toList())),
        ]),
      ),
    );
  }
}

class CalibrationPage extends StatefulWidget {
  const CalibrationPage({super.key});
  @override
  State<CalibrationPage> createState() => _CalibrationPageState();
}

class _CalibrationPageState extends State<CalibrationPage> {
  double? pH_point1_raw;
  double? pH_point2_raw;
  double? pH_point1_actual;
  double? pH_point2_actual;
  double? moist_dry_obs;
  double? moist_wet_obs;

  @override
  void initState() {
    super.initState();
    final appState = Provider.of<AppState>(context, listen: false);
    pH_point1_raw = null;
    pH_point2_raw = null;
    pH_point1_actual = null;
    pH_point2_actual = null;
    moist_dry_obs = appState.moistDryObserved;
    moist_wet_obs = appState.moistWetObserved;
  }

  void _capturePhRaw(int slot) {
    final appState = Provider.of<AppState>(context, listen: false);
    final raw = appState.latest['pH'];
    if (raw == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No pH reading available')));
      return;
    }
    setState(() {
      if (slot == 1) pH_point1_raw = raw;
      else pH_point2_raw = raw;
    });
  }

  void _savePhCalibration() {
    if (pH_point1_raw == null || pH_point2_raw == null || pH_point1_actual == null || pH_point2_actual == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Capture two points and enter actual values')));
      return;
    }
    // compute linear mapping raw -> actual: actual = m*raw + b
    final m = (pH_point2_actual! - pH_point1_actual!) / (pH_point2_raw! - pH_point1_raw!);
    final b = pH_point1_actual! - m * pH_point1_raw!;
    Provider.of<AppState>(context, listen: false).savePhCalibration(m, b);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('pH calibration saved')));
  }

  void _captureMoist(int slot) {
    final appState = Provider.of<AppState>(context, listen: false);
    final raw = appState.latest['moist'];
    if (raw == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No moisture reading available')));
      return;
    }
    setState(() {
      if (slot == 1) moist_dry_obs = raw;
      else moist_wet_obs = raw;
    });
  }

  void _saveMoistCalibration() {
    if (moist_dry_obs == null || moist_wet_obs == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Capture dry and wet observed values')));
      return;
    }
    Provider.of<AppState>(context, listen: false).saveMoistCalibration(moist_dry_obs!, moist_wet_obs!);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Moisture calibration saved')));
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Calibration')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('pH Calibration (Two-point)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height:6),
            Row(children: [
              ElevatedButton(onPressed: () => _capturePhRaw(1), child: const Text('Capture raw (Point 1)')),
              const SizedBox(width:8),
              Text(pH_point1_raw == null ? 'Not captured' : 'Raw1: ${pH_point1_raw}'),
            ]),
            const SizedBox(height:8),
            TextField(decoration: const InputDecoration(labelText: 'Actual pH for point 1 (e.g., 7.00)'), keyboardType: TextInputType.numberWithOptions(decimal: true), onChanged: (v){ pH_point1_actual = double.tryParse(v); }),
            const SizedBox(height:8),
            Row(children: [
              ElevatedButton(onPressed: () => _capturePhRaw(2), child: const Text('Capture raw (Point 2)')),
              const SizedBox(width:8),
              Text(pH_point2_raw == null ? 'Not captured' : 'Raw2: ${pH_point2_raw}'),
            ]),
            const SizedBox(height:8),
            TextField(decoration: const InputDecoration(labelText: 'Actual pH for point 2 (e.g., 4.00)'), keyboardType: TextInputType.numberWithOptions(decimal: true), onChanged: (v){ pH_point2_actual = double.tryParse(v); }),
            const SizedBox(height:8),
            ElevatedButton(onPressed: _savePhCalibration, child: const Text('Save pH Calibration')),
            const Divider(),
            const Text('Moisture Calibration (Dry & Wet observed)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height:6),
            Row(children: [
              ElevatedButton(onPressed: () => _captureMoist(1), child: const Text('Capture Dry (Point 1)')),
              const SizedBox(width:8),
              Text(moist_dry_obs == null ? 'Not captured' : 'Dry: ${moist_dry_obs}'),
            ]),
            const SizedBox(height:8),
            Row(children: [
              ElevatedButton(onPressed: () => _captureMoist(2), child: const Text('Capture Wet (Point 2)')),
              const SizedBox(width:8),
              Text(moist_wet_obs == null ? 'Not captured' : 'Wet: ${moist_wet_obs}'),
            ]),
            const SizedBox(height:8),
            ElevatedButton(onPressed: _saveMoistCalibration, child: const Text('Save Moisture Calibration')),
            const SizedBox(height:12),
            const Text('Notes: For pH, use buffer solutions (pH 7 and pH 4). For moisture, measure in air (dry) and saturated soil (wet).'),
          ]),
        ),
      ),
    );
  }
}

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});
  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('History')),
      body: ListView(children: appState.logs.map((l)=>ListTile(title:Text(l))).toList()),
    );
  }
}
